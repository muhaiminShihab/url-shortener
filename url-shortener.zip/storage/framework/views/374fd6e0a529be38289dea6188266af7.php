<?php $__env->startSection('page_section'); ?>
    <section class="main-area">
        <div class="container">
            
            <?php echo $__env->make('layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-md-6 mx-auto mt-150">
                <div class="card border-0 shadow px-4">
                    <div class="card-body">
                        <div class="text-center mb-5">
                            <h2 class="fw-bold">Sign-in to Account</h2>
                            <p>Make your long URL's short, easy and free !!</p>
                        </div>
                        <form action="<?php echo e(route('sign_in_page')); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <div class="form-group mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" id="" placeholder="abc@xyz.com"
                                    class="form-control" required>
                            </div>
                            <div class="form-group mb-3">
                                <label class="form-label">Password</label>
                                <input type="password" name="password" id="" placeholder="********"
                                    class="form-control" required>
                            </div>
                            <div class="form-group text-end">
                                <button type="submit" class="btn btn-primary">Sign-in</button>
                            </div>
                        </form>
                        <div class="text-center mt-4">
                            <a href="<?php echo e(route('sign_up_page')); ?>">Have no account? Click here.</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\url-shortener\resources\views/auth/sign-in.blade.php ENDPATH**/ ?>