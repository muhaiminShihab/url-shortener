<div class="row py-4">
    <div class="col-12 text-center text-md-end">
        <a href="<?php echo e(route('home_page')); ?>" class="px-3 text-dark">Home</a>
        <?php if( Auth::check() ): ?>
            <a href="<?php echo e(route('dashboard_page')); ?>" class="px-3 text-dark">Dashboard</a>
            <a href="<?php echo e(route('api_docs_page')); ?>" class="px-3 text-dark">API</a>
            <a href="<?php echo e(route('sign_out')); ?>" class="px-3 text-dark">Logout</a>
        <?php else: ?>
            <a href="<?php echo e(route('sign_in_page')); ?>" class="px-3 text-dark">Sign-in</a>
            <a href="<?php echo e(route('sign_up_page')); ?>" class="px-3 text-dark">Sign-up</a>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\laragon\www\url-shortener\resources\views/layout/menu.blade.php ENDPATH**/ ?>